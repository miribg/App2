package com.example.softw1;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class Registro extends AppCompatActivity  {

    private EditText et1, et2, et3, et4, et5, et6;
    private Button btn;

    private String str_name, str_uName, str_surname, str_password, str_email, str_phone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        et1=(EditText) findViewById(R.id.uNombreText);
        et2=(EditText) findViewById(R.id.nombreText);
        et3=(EditText) findViewById(R.id.apellidosText);
        et4=(EditText) findViewById(R.id.contraseñaText);
        et5=(EditText) findViewById(R.id.emailText);
        et6=(EditText) findViewById(R.id.phoneText);

        btn=(Button) findViewById(R.id.buttonReg);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                str_uName = et1.getText().toString().trim();
                str_name = et2.getText().toString().trim();
                str_surname=et3.getText().toString().trim();
                str_password=et4.getText().toString().trim();
                str_email=et5.getText().toString().trim();
                str_phone=et6.getText().toString().trim();

                if (!str_name.isEmpty() && !str_password.isEmpty()
                    && !str_email.isEmpty() && !str_phone.isEmpty() && !str_uName.isEmpty()) {
                        comprobarNombreUsuario();
                } else {
                    Toast.makeText(Registro.this, "Algún parametro vacio", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    private void comprobarNombreUsuario(){
        String url = "http://192.168.1.134/developeru/doble.php";
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(Registro.this,""+response,Toast.LENGTH_LONG).show();
                if (response != null && response.length()>0) {
                    Toast.makeText(Registro.this, "ENTRA1", Toast.LENGTH_SHORT).show();
                    if ( response.equalsIgnoreCase("correcto")) {
                        registrar();
                    } else{
                        et1.setText("", TextView.BufferType.EDITABLE);
                    }
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                //TODO: CAMBIAR
                Toast.makeText(Registro.this, error.toString(), Toast.LENGTH_LONG).show();
                Log.d("error",error.toString());
            }
        }
        ) {
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> parametros = new HashMap<String, String>();
                parametros.put("user_name", str_uName);
                return parametros;
            }
        };
        RequestQueue requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }
    private void registrar(){
        String url = "http://192.168.1.130/developeru/registrar.php";
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(Registro.this,""+response,Toast.LENGTH_LONG).show();
                if (response != null && response.length()>0){
                    Toast.makeText(Registro.this, ""+response, Toast.LENGTH_SHORT).show();
                    if (response.equalsIgnoreCase("registro correcto")) {
                        Intent intent = new Intent(getApplicationContext(), MenuPrincipal.class);
                        intent.putExtra("name", str_surname);
                        startActivity(intent);
                    }else {
                        Toast.makeText(Registro.this, "Algún dato incorrecto", Toast.LENGTH_LONG).show();
                    }
                }else{
                    Toast.makeText(Registro.this, "No parametrs", Toast.LENGTH_LONG).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                //TODO: CAMBIAR
                Toast.makeText(Registro.this, error.toString(), Toast.LENGTH_LONG).show();
                Log.d("error",error.toString());
            }
        }
        ) {
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> parametros = new HashMap<String, String>();
                parametros.put("user_name", str_uName);
                parametros.put("password", str_password);
                parametros.put("surname",str_surname);
                parametros.put("email", str_email);
                parametros.put("phone", str_phone);
                parametros.put("name", str_name);
                return parametros;
            }
        };
        RequestQueue requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

}