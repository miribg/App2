package com.example.softw1;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private EditText et1, et2;
    private TextView btn_reg;
    private Button btn_iniciar;

    private String str_name, str_password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // abrir la app
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); //Unión entre vista y controlador
        //Toast: mostra un mensaje, Toast.makeText(sitio, texto, duración)
        Toast.makeText(this, "OnCreate", Toast.LENGTH_SHORT).show();
        // La actividad está creada.

        et1 = (EditText) findViewById(R.id.nombreUsuario);
        et2 = (EditText) findViewById(R.id.contraseñaUsuario);

        btn_reg = (TextView) findViewById(R.id.regView);
        btn_reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentReg = new Intent(MainActivity.this, Registro.class);
                startActivity(intentReg);
            }
        });


        btn_iniciar = (Button) findViewById(R.id.buttonIn);
        btn_iniciar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                str_name = et1.getText().toString().trim();
                str_password = et2.getText().toString().trim();
                if (!str_name.isEmpty() && !str_password.isEmpty()) {
                   validarUsuario();
                } else {
                    Toast.makeText(MainActivity.this, "Algún parametro vacio", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void validarUsuario()  {
        String url = "http://192.168.1.134/developeru/validar_usuario.php";
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(MainActivity.this,""+response,Toast.LENGTH_LONG).show();
                if (response != null && response.length()>0){
                    Toast.makeText(MainActivity.this, "ENTRA1", Toast.LENGTH_SHORT).show();
                    if (response.equalsIgnoreCase("ingreso correctamente")) {
                        Intent intent = new Intent(getApplicationContext(), MenuPrincipal.class);
                        intent.putExtra("name",str_name);
                        startActivity(intent);
                    }else {
                        Toast.makeText(MainActivity.this, "Nombre de usuario o contraseña incorrecta", Toast.LENGTH_LONG).show();
                    }
                }else{
                    Toast.makeText(MainActivity.this, "No parametrs", Toast.LENGTH_LONG).show();
                }
            }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                //TODO: CAMBIAR
                    Toast.makeText(MainActivity.this, error.toString(), Toast.LENGTH_LONG).show();
                    Log.d("error",error.toString());
                }
            }
        ) {
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> parametros = new HashMap<String, String>();
                parametros.put("user_name", str_name);
                parametros.put("password", str_password);
                return parametros;
            }
        };
        RequestQueue requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
        Toast.makeText(MainActivity.this, "ENTRA4", Toast.LENGTH_SHORT).show();
    }


    @Override
    protected void onStart() {
        // reiniciar
        super.onStart();
        Toast.makeText(this, "OnStart", Toast.LENGTH_SHORT).show();
        // La actividad está a punto de hacerse visible.
    }
    @Override
    protected void onResume() {
        // hacer visible
        super.onResume();
        Toast.makeText(this, "OnResume", Toast.LENGTH_SHORT).show();
        // La actividad se ha vuelto visible (ahora se "reanuda").
    }
    @Override
    protected void onPause() {
         // Pausar la actividad: poner la app en 2 plano
        super.onPause();
        Toast.makeText(this, "OnPause", Toast.LENGTH_SHORT).show();
        // Enfocarse en otra actividad  (esta actividad est� a punto de ser "detenida").
    }
    @Override
    protected void onStop() {
        //Oculta la actividad: 2 plano
        super.onStop();
        Toast.makeText(this, "OnStop", Toast.LENGTH_SHORT).show();
        // La actividad ya no es visible (ahora est� "detenida")
    }
    @Override
    protected void onDestroy() {
        // cerrar la app:  no se puede recuoerar
        super.onDestroy();
        Toast.makeText(this, "OnDestroy", Toast.LENGTH_SHORT).show();
        // La actividad est� a punto de ser destruida.
    }

}