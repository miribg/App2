package com.example.softw1;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.icu.util.Calendar;
import android.os.Bundle;
import android.util.Log;
import android.widget.CalendarView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.time.DayOfWeek;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class MenuPrincipal extends AppCompatActivity {

    CalendarView cal;
    String fecha;

    String str_name;
    //TODO Pasar us_name de la anterior view
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal);

        str_name= getIntent().getExtras().getString("name");

        cal=(CalendarView) findViewById(R.id.calendarView);
        cal.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView calendarView, int año,
                                            int mes, int dia) {
                fecha=dia+"/"+mes+"/"+año;
                Toast.makeText(MenuPrincipal.this, fecha,Toast.LENGTH_SHORT).show();
                Toast.makeText(MenuPrincipal.this, "2" ,Toast.LENGTH_SHORT).show();
                opciones(fecha);
            }
        });


    }

    private void opciones(String fecha){
        String url="http://192.168.1.134/developeru/admin.php";
        Toast.makeText(MenuPrincipal.this, str_name,Toast.LENGTH_SHORT).show();
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(MenuPrincipal.this,""+response,Toast.LENGTH_LONG).show();
                if (response != null && response.length()>0){;
                    if (response.equalsIgnoreCase("admin")) {
                        //TODO cambiar color
                        AlertDialog al= crearEvento(fecha);
                    }else{
                        //no admin
                    }
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                //TODO: CAMBIAR
                Toast.makeText(MenuPrincipal.this, error.toString(), Toast.LENGTH_LONG).show();
                Log.d("error",error.toString());
            }
        }
        ) {
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> parametros = new HashMap<String, String>();
                parametros.put("user_name", str_name);
                return parametros;
            }
        };
        RequestQueue requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    private AlertDialog crearEvento(String fecha){
        Toast.makeText(MenuPrincipal.this, "CREAR EV", Toast.LENGTH_SHORT).show();
        AlertDialog.Builder builder = new AlertDialog.Builder(MenuPrincipal.this);

        builder.setTitle("Crear evento").setMessage("¿Quieres añadir un evento en la fecha"+fecha+"?")
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                //lista
                                Toast.makeText(MenuPrincipal.this, "Lista", Toast.LENGTH_SHORT).show();
                            }
                        })
                .setNegativeButton("CANCELAR", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        });

        return builder.create();
    }

}